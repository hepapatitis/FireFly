.------------------------------------.
|  Firely READ ME                    |
'------------------------------------'

Thank you for purchasing Firely template.
If you haven't seen the demo, please do so.

Demo URL: http://demo.memoriesdust.com/template/firely/

To use the coming soon template that you want, simply copy the folder that you want.

If you have any question, please do not hesitate to ask me at

Email        : support@memoriesdust.com
Q&A Support  : http://memoriesdust.freshdesk.com

Warmest Regards,
Memories Dust
